
public class Girokonto extends AbstraktKonto 
{
	private int _dispo;
	
	@Override
	public void abheben(int betrag) 
	{
		if(super._saldo + _dispo >= betrag)
		{
			super._saldo -= betrag;
		}
	}
}
