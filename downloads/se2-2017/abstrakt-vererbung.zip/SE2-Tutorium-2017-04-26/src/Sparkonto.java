
public class Sparkonto extends AbstraktKonto 
{
	@Override
	public void abheben(int betrag) 
	{
		if(super._saldo >= betrag)
		{
			super._saldo -= betrag;
		}
	}
}
