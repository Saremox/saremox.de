
public abstract class AbstraktKonto 
{
	protected int _saldo;

	public final void einzahlen(int betrag) 
	{
		if(betrag > 0)
		{
			_saldo += betrag;

		}
	}

	abstract public void abheben(int betrag);

	public int gibSaldo() 
	{
		return _saldo;
	}
}